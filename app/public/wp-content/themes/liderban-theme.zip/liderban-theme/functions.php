<?php
/**
 * Funcoes do tema Liderban.
 *
 * @package Liderban_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function liderban_theme_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

	register_nav_menus(
		array(
			'primary' => __( 'Menu principal', 'liderban-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'liderban_theme_setup' );

function liderban_theme_enqueue_assets() {
	$style_path = get_stylesheet_directory() . '/style.css';
	$version    = file_exists( $style_path ) ? filemtime( $style_path ) : wp_get_theme()->get( 'Version' );

	wp_enqueue_style(
		'liderban-theme-style',
		get_stylesheet_uri(),
		array(),
		$version
	);
}
add_action( 'wp_enqueue_scripts', 'liderban_theme_enqueue_assets' );

function liderban_theme_menu_fallback() {
	$items = array(
		'Quem Somos'    => home_url( '/quem-somos/' ),
		'Onde Estamos' => home_url( '/onde-estamos/' ),
		'Soluções'     => home_url( '/solucoes/' ),
		'BanBan'       => home_url( '/banban/' ),
		'LB News'      => home_url( '/lb-news/' ),
		'Contato'      => home_url( '/contato/' ),
	);

	echo '<ul class="primary-menu">';

	foreach ( $items as $label => $url ) {
		printf(
			'<li><a href="%1$s">%2$s</a></li>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	echo '</ul>';
}

