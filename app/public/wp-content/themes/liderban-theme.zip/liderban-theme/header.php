<?php
/**
 * Cabecalho do tema.
 *
 * @package Liderban_Theme
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
	<div class="site-header__inner">
		<a class="site-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Liderban - inicio', 'liderban-theme' ); ?>">
			<span>Liderban</span><span class="site-logo__dot">.</span>
		</a>

		<nav class="site-navigation" aria-label="<?php esc_attr_e( 'Menu principal', 'liderban-theme' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_class'     => 'primary-menu',
					'container'      => false,
					'fallback_cb'    => 'liderban_theme_menu_fallback',
					'depth'          => 1,
				)
			);
			?>

			<a class="site-header__cta" href="<?php echo esc_url( home_url( '/contato/' ) ); ?>">
				<?php esc_html_e( 'Solicite um Orçamento', 'liderban-theme' ); ?>
			</a>
		</nav>
	</div>
</header>

