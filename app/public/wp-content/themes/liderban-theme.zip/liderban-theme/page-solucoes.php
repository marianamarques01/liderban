<?php
/**
 * Template Name: Soluções
 * Template Post Type: page
 *
 * @package Liderban_Theme
 */

get_header();
?>

<main id="primary" class="site-main">
	<article class="solutions-page" aria-labelledby="solutions-title">
		<header>
			<h1 id="solutions-title" class="solutions-page__title"><?php esc_html_e( 'Soluções', 'liderban-theme' ); ?></h1>
		</header>

		<section class="solutions-hero" aria-labelledby="solutions-hero-title">
			<h2 id="solutions-hero-title" class="solutions-hero__heading">
				<?php esc_html_e( 'Agilidade no agendamento e assertividade de entrega', 'liderban-theme' ); ?>
			</h2>

			<aside class="solutions-stat" aria-label="<?php esc_attr_e( 'Numero de ordens de servico', 'liderban-theme' ); ?>">
				<p class="solutions-stat__label"><?php esc_html_e( 'Número de ordens de Serviço:', 'liderban-theme' ); ?></p>
				<p class="solutions-stat__value">
					<span class="solutions-stat__number"><?php esc_html_e( '30mil', 'liderban-theme' ); ?></span>
					<span class="solutions-stat__suffix"><?php esc_html_e( 'ordens mensais', 'liderban-theme' ); ?></span>
				</p>
			</aside>
		</section>

		<section class="solutions-intro" aria-labelledby="solutions-services-title">
			<div class="solutions-section-heading">
				<svg class="solutions-section-heading__icon" viewBox="0 0 96 96" role="img" aria-labelledby="gear-title">
					<title id="gear-title"><?php esc_html_e( 'Engrenagem', 'liderban-theme' ); ?></title>
					<circle cx="48" cy="48" r="43" fill="none" stroke="currentColor" stroke-width="4" />
					<circle cx="48" cy="48" r="16" fill="none" stroke="currentColor" stroke-width="5" />
					<path d="M48 18v9M48 69v9M18 48h9M69 48h9M27 27l7 7M62 62l7 7M69 27l-7 7M34 62l-7 7" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="5" />
					<path d="M42 28h12l3 9 9 4v14l-9 4-3 9H42l-3-9-9-4V41l9-4z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="4" />
				</svg>

				<h2 id="solutions-services-title" class="solutions-section-heading__title"><?php esc_html_e( 'Serviços', 'liderban-theme' ); ?></h2>
			</div>

			<p class="solutions-intro__text">
				<?php esc_html_e( 'Oferecemos um portfólio completo de serviços voltados ao saneamento móvel, gestão de resíduos e logística especializada. Com foco em tecnologia de alta performance e rigor técnico, entregamos soluções que garantem a conformidade ambiental e a eficiência operacional de cada processo, mitigando riscos e promovendo o cuidado com as pessoas e com o meio ambiente em todos os nossos atendimentos.', 'liderban-theme' ); ?>
			</p>
		</section>
	</article>
</main>

<?php
get_footer();

