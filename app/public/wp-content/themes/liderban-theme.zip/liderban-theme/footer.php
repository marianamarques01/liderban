<?php
/**
 * Rodape do tema.
 *
 * @package Liderban_Theme
 */
?>
<footer class="site-footer">
	<div class="site-footer__inner">
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Liderban.</p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>

