<?php
/**
 * Template principal do tema.
 *
 * @package Liderban_Theme
 */

get_header();
?>

<main id="primary" class="site-main">
	<section class="solutions-page" aria-labelledby="page-title">
		<?php if ( have_posts() ) : ?>
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<h1 id="page-title" class="solutions-page__title"><?php the_title(); ?></h1>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			<?php endwhile; ?>
		<?php else : ?>
			<h1 id="page-title" class="solutions-page__title"><?php esc_html_e( 'Liderban', 'liderban-theme' ); ?></h1>
		<?php endif; ?>
	</section>
</main>

<?php
get_footer();

